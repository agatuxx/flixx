header{
    border-bottom: solid 3px rgb (42, 122, 218);
    padding : 30 px;
    font-size: 40 px;
}